<?php

    include 'koneksi.php';

    $qry = "SELECT * FROM tumbuhan";
    $result = $conn->query($qry);

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD Tumbuhan</title>
</head>
<body>
    <h2>Data Tumbuhan</h2>
    <table border="1" style="width:100%">
        <tr>
            <th>ID</th>
            <th>Nama</th>
            <th>Jenis Biji</th>
            <th>Bentuk Akar</th>
            <th>Jenis Kayu</th>
            <th>Aksi</th>
        </tr>
     

        <?php while( $row = $result->fetch_assoc() ) :  ?>
        <tr>
            <td> <?= $row['id'] ?>  </td>
            <td><?= $row['nama'] ?></td>
            <td><?= $row['jenis_biji'] ?></td>
            <td><?= $row['bentuk_akar'] ?></td>
            <td><?= $row['jenis_kayu'] ?></td>
            <td>
                <a href="edit.php">Edit</a>
                <a href="delete.php">Delete</a>
            </td>
        </tr>
        <?php  endwhile  ?>

    </table>
    <br>
    <h2>Tambah Tumbuhan</h2>
    <form action="insert.php" method="POST">
        Nama: <input type="text" name="nama" required><br>
        Jenis Biji: <input type="text" name="jenis_biji" required><br>
        Bentuk Akar: <input type="text" name="jenis_akar" required><br>
        Jenis Kayu: <input type="text" name="jenis_kayu" required><br>
        <input type="submit" value="Tambah">
    </form>
</body>
</html>