<?php

$host = 'localhost';
$username = 'root';
$password = '';
$database = 'tumbuhan1';

$conn = new mysqli($host, $username, $password, $database);