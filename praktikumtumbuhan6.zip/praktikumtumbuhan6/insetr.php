<?php

include 'koneksi.php';    

$nama = $_POST['nama'];
$nim = $_POST['jenis_biji'];
$jurusan = $_POST['bentuk_akar'];
$semester = $_POST['jenis_kayu'];

$query = "INSERT INTO tumbuhan (nama, jenis_biji, bentuk_akar, jenis_kayu)
            VALUES ('$nama', '$jenis_biji', '$bentuk_akar', '$jenis_kayu')";

if( $conn->query($query) === TRUE ) {
    header("Location: index.php");
}


$conn->close();